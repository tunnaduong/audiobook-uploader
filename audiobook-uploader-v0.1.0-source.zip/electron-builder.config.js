module.exports = {
  appId: 'com.audiobook-uploader.app',
  productName: 'Audiobook Uploader',
  files: [
    'dist/electron/**/*.js',
    'dist/renderer/**/*',
    'package.json',
  ],
  directories: {
    buildResources: 'public',
  },
  win: {
    target: [
      {
        target: 'portable',
        arch: ['x64'],
      },
    ],
  },
  nsis: {
    oneClick: false,
    allowToChangeInstallationDirectory: true,
    createDesktopShortcut: true,
    createStartMenuShortcut: true,
  },
};
